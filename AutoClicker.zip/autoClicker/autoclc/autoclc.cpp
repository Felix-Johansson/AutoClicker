#include <iostream>
#include <Windows.h>

int main()
{
    while (true)
    {
        if ((GetAsyncKeyState('O') & 0x8000) && (GetAsyncKeyState(VK_LSHIFT) & 0x8000))
        {
            INPUT input = { 0 };
            input.type = INPUT_MOUSE;
            input.mi.dwFlags = MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP;
            while (true)
            {
                SendInput(1, &input, sizeof(INPUT));
                if ((GetAsyncKeyState('I') & 0x8000) &&  (GetAsyncKeyState(VK_LSHIFT) & 0x8000)){
                    break;
                }
                Sleep(1);
            }
        }
    }
    return 0;
}